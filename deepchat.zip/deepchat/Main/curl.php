<?php
if (function_exists('curl_init')) {
    echo "cURL is enabled";
} else {
    echo "cURL is not enabled";
}
?>
